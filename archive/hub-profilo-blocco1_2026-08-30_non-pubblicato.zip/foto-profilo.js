#!/usr/bin/env node
/* foto-profilo.js — fotografa la homepage del Profilo a computer e a telefono.
 *   node foto-profilo.js app.html prima|dopo
 * Non e' un banco: non dice ne' si' ne' no. Serve a guardare.
 */
var fs = require("fs");
var path = require("path");
var os = require("os");
var { chromium } = require("playwright");

var FILE = process.argv[2] || "app.html";
var TAG  = process.argv[3] || "ora";
var src = fs.readFileSync(FILE, "utf8");

/* IN DEV_MODE `currentUser` RESTA `null`, e tre porte su sei vogliono un
   utente: Persone bloccate, Spazio compagnia e Amministrazione. Senza, la
   foto mostrerebbe mezza pagina e sembrerebbe giusta. Qui si finge un utente
   con l'indirizzo dell'admin: e' un trucco del banco di prova, non
   dell'app. */
var D = fs.mkdtempSync(path.join(os.tmpdir(), "foto-"));
var provato = src
  .replace("var DEV_MODE = false;", "var DEV_MODE = true;")
  .replace("var currentUser = null;",
           'var currentUser = { uid:"finto", email:"alessandro.zanetta80@gmail.com" };');
fs.writeFileSync(path.join(D, "index.html"), provato);
["compagnie-data.js", "logo.webp", "logo.jpg"].forEach(function(x){
  if (fs.existsSync(x)) fs.copyFileSync(x, path.join(D, x));
});

/* Uno storico vero, se no le carte statistiche non si disegnano e la foto
   del PRIMA non mostra quello che stiamo togliendo. */
function giro(d, tot, per){
  return { date:d, modeLabel:"Percorso 24", modeKey:"fiarc_percorso", format:24,
           sessionType:"3d", scoringVersion:2, campo:"Fornasona, Cerrione",
           results:[{ name:"Alessandro Zanetta", isSelf:true, total:tot, perTarget:per }] };
}
var per24 = []; for(var i=0;i<24;i++) per24.push(15);
var STORIA = [
  giro("2026-08-20T09:00:00.000Z", 342, per24),
  giro("2026-08-13T09:00:00.000Z", 318, per24),
  giro("2026-08-06T09:00:00.000Z", 305, per24),
  giro("2026-07-30T09:00:00.000Z", 291, per24),
  giro("2026-07-23T09:00:00.000Z", 288, per24),
  giro("2026-07-16T09:00:00.000Z", 276, per24)
];

var STATO = { screen:"menu", tab:"profilo", pendingArchers:[], lang:"it", country:"it",
  federation:"fiarc", theme:"light", profileSkipped:false,
  profile:{ nomeCognome:"Alessandro Zanetta", username:"alez", arco:"longbow",
            compagnia:"01VERB", compagniaNome:"Arcieri del Verbano" } };

(async function(){
  var browser = await chromium.launch();
  async function scatta(w, h, nome){
    var ctx = await browser.newContext({ viewport:{ width:w, height:h } });
    var p = await ctx.newPage();
    var err = [];
    p.on("pageerror", function(e){ err.push(String(e.message)); });
    await p.addInitScript(function(a){
      localStorage.setItem("arctrail3d_state_v3", JSON.stringify(a.st));
      localStorage.setItem("arctrail3d_welcome_v2", "1");
      localStorage.setItem("arctrail3d_storico_v1", JSON.stringify(a.hi));
    }, { st:STATO, hi:STORIA });
    await p.goto("file:///" + path.join(D, "index.html").split(path.sep).join("/"));
    await p.waitForTimeout(1100);
    await p.evaluate(function(){
      var a = Array.prototype.slice.call(document.querySelectorAll("header .bar-btn"))
        .filter(function(x){ return x.textContent.trim() === "A"; })[0];
      if(a) a.click();
    });
    await p.waitForTimeout(700);
    var f = "foto-" + nome + "-" + TAG + ".png";
    await p.screenshot({ path:f, fullPage:true });
    var quante = await p.evaluate(function(){
      return document.querySelectorAll(".menu-btn").length;
    });
    console.log("  " + f + "  porte:" + quante + (err.length ? "  ERRORI: " + err[0] : ""));
    await ctx.close();
  }
  await scatta(1280, 900, "computer");
  await scatta(390, 844, "telefono");
  await browser.close();
})().catch(function(e){ console.error("rotto:", e.message); process.exit(1); });
